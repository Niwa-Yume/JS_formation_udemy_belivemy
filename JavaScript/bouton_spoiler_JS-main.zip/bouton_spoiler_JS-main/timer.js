
//Initalisation des variables
let btn = document.querySelector('button');
let secondes = 10;
let interval;
//lors d'un click sur le bouton déclenche la fonction start et l'interval
btn.addEventListener('click', start);
//La fonction start
function start() {
  interval = setInterval(decompte, 1000);
}
//Fonction stop
function stop() {
//Stop l'ajout interval
  clearInterval(interval);
  document.body.innerHTML += "Stop !";
}

function decompte() {
  //Permet de décrémenter
  secondes--;
  if(secondes == 0) {
    stop();
  }
  else {
    document.body.innerHTML += secondes + '<br>';
  }
  
}